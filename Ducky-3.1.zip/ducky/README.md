# Ducky 3.1 — Volumen Extra

Amplificador de audio para Chrome / Edge (Manifest V3), hasta 600 %.

## Instalar
1. Abre `chrome://extensions` y activa el **modo de desarrollador**.
2. Quita la versión anterior (Volumen Extra 2.0). Los ajustes por sitio se conservan.
3. Pulsa **Cargar descomprimida** y elige esta carpeta.
4. Recarga las pestañas que ya tenías abiertas.

## Uso
- Usa el deslizador (también con la rueda del ratón), los botones − / + (25 %) o los niveles rápidos.
- Cada sitio recuerda su propio volumen. Los sitios nuevos empiezan en 100 %.

## Atajos
- `Alt+Shift+↑` subir 25 %  ·  `Alt+Shift+↓` bajar 25 %  ·  `Alt+Shift+0` volver a 100 %
- Se cambian en `chrome://extensions/shortcuts`.

## Archivos
- `manifest.json` — permisos, íconos, atajos.
- `content.js` — cadena de Web Audio compartida (graves → ganancia → limitador → salida).
- `popup.html` / `popup.css` / `popup.js` — interfaz; el círculo detrás del pato se mueve con el audio.
- `background.js` — insignia con el porcentaje y atajos.
- `duck.png` / `icon*.png` — logo; los íconos de 16 y 32 px usan solo la cabeza para que se lea.
- `fonts/` — Bricolage Grotesque y Onest (licencia OFL), incluidas para funcionar sin internet.
